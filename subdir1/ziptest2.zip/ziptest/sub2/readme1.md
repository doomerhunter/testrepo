copper-project
/
copper-rs
Public
Code
Issues
7
Pull requests
1
Discussions
Actions
Projects
Wiki
Security
Insights
Copper Release Log
Guillaume Binet edited this page 8 hours ago · 28 revisions
Release Notes - v0.5.0 - 2024-12-02
New Features
Deterministic Log Replay: Copper can now replay a log through your code in a deterministic fashion ie. if your tasks are deterministic, it will always output the same output from the same input! See the balancebot-resim for example.

Aligner Task #114: Added an aligner task that synchronizes multiple inputs by aligning matching time windows, facilitating coordinated data processing. This is particularly useful for sensor fusion.

❗ Lifecycle Trait Removal #115: Removed the lifecycle trait to simplify task implementation and decouple passed types, streamlining the codebase. To build a minimum task a user needed to implement one method from the CuTaskLifecycle trait (new) and at least the process method from they flavor of tasks. This was forcing the implementation of 2 mandatory traits which is not necessary or useful for the user. Now we moved all the lifecycle methods in the tasks trait to only have to implement 2 traits (the task and Freezable, the serialization of its state)

Enhancements
Named Output Mapping on CopperLists #121: Implemented mapping of Copperlist indices to named outputs from tasks, allowing users to access task outputs symbolically without relying on execution order.

CuTimeRange Introduction #106: Introduced CuTimeRange to represent messages containing multiple Time of Validity (TOV) instances, such as sequences of images or IMU measurements.
